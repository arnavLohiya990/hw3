// R.McQuesten-TP2, 2025-02-25, JUnit validate questions class 
package unitTests;

import application.Question;
import application.Questions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.NoSuchElementException;

public class QuestionsTest {

    private Questions questions;

    @BeforeEach
    public void setUp() {
        questions = new Questions();
    }

    @Test
    public void testAddAndGetQuestion() {
        questions.addQuestion("Demo Question?", "Demo Answer.", 1);
        Question q = questions.getQuestion(1);
        assertNotNull(q);
        assertEquals("Demo Question?", q.getTitle());
        assertEquals("Demo Answer.", q.getBody());
    }

    @Test
    public void testUpdateQuestion() {
        questions.addQuestion("Old Title", "Old Body", 2);
        questions.updateQuestion(2, "New Title");
        Question q = questions.getQuestion(2);
        assertNotNull(q);
        assertEquals("New Title", q.getTitle());
    }

    @Test
    public void testUpdateNonExistentQuestion() {
        Exception exception = assertThrows(NoSuchElementException.class, () -> {
            questions.updateQuestion(99, "New Title");
        });
        assertEquals("Question not found.", exception.getMessage());
    }

    @Test
    public void testDeleteQuestion() {
        questions.addQuestion("Delete Me", "Demo Text", 3);
        questions.deleteQuestion(3);
        assertNull(questions.getQuestion(3));
    }

    @Test
    public void testGetAllQuestions() {
        questions.addQuestion("Title1", "Body1", 4);
        questions.addQuestion("Title2", "Body2", 5);
        assertEquals(2, questions.getAllQuestions().size());
    }
}
