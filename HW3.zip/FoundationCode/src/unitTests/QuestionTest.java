// R.McQuesten-TP2, 2025-02-25, JUnit validate question class 
package unitTests;

import application.Question;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class QuestionTest {

    @Test
    public void testConstructorAndGettersWithOwnerUserId() {
        int ownerUserId = 1;
        String title = "Demo Title";
        String body = "Demo Body for Question";
        Question question = new Question(ownerUserId, title, body);
        assertEquals(ownerUserId, question.getOwnerUserId());
        assertEquals(title, question.getTitle());
        assertEquals(body, question.getBody());
    }

    @Test
    public void testConstructorWithOwnerName() {
        String ownerName = "Demo User";
        int ownerUserId = 2;
        String title = "Demo Title";
        String body = "Demo Body";
        int questionId = 100;
        Question question = new Question(ownerName, ownerUserId, title, body, questionId);
        assertEquals(ownerName, question.getOwnerName());
        assertEquals(ownerUserId, question.getOwnerUserId());
        assertEquals(title, question.getTitle());
        assertEquals(body, question.getBody());
        assertEquals(questionId, question.getQuestionId());
    }

    @Test
    public void testSetters() {
        Question question = new Question(3, "Initial Title", "Initial Body");
        question.setTitle("Updated Demo Title");
        question.setBody("Updated Demo Body");
        question.setOwnerName("Demo User");
        question.setQuestionId(50);
        assertEquals("Updated Demo Title", question.getTitle());
        assertEquals("Updated Demo Body", question.getBody());
        assertEquals("Demo User", question.getOwnerName());
        assertEquals(50, question.getQuestionId());
    }

    @Test
    public void testToString() {
        Question question = new Question("Bob", 5, "Question Title", "Question Body", 10);
        String expected = "Question ID: 10, Title: Question Title, Owner: Bob";
        assertEquals(expected, question.toString());
    }
}
