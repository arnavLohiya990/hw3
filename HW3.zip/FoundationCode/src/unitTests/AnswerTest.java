// R.McQuesten-TP2, 2025-02-25, JUnit validate answer class 
package unitTests;

import application.Answer;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AnswerTest {

    @Test
    public void testAnswerCreation() {
        Answer answer = new Answer(10, "Demo answer.", "Demo User");
        assertEquals(10, answer.getQuestionId());
        assertEquals("This is an answer.", answer.getText());
        assertEquals("Demo User", answer.getAuthor());
        assertNotNull(answer.getCreatedAt());
    }

    @Test
    public void testEmptyAnswerThrowsException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Answer(10, "", "Demo User");
        });
        assertEquals("Answer text cannot be empty.", exception.getMessage());
    }
}
