// R.McQuesten-TP2, 2025-02-25, JUnit validate answers class 
package unitTests;

import application.Answer;
import application.Answers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

public class AnswersTest {

    private Answers answers;

    @BeforeEach
    public void setUp() {
        answers = new Answers();
    }

    @Test
    public void testAddAndRetrieveAnswer() {
        answers.addAnswer(20, "Answer for question 20", "Demo User");
        List<Answer> answerList = answers.getAnswersForQuestion(20);
        assertEquals(1, answerList.size());
        Answer ans = answerList.get(0);
        assertEquals("Answer for question 20", ans.getText());
        assertEquals("Demo User", ans.getAuthor());
    }

    @Test
    public void testDeleteAnswer() {
        answers.addAnswer(30, "Answer for question 30", "Bob");
        List<Answer> answerList = answers.getAnswersForQuestion(30);
        assertEquals(1, answerList.size());
        Answer ans = answerList.get(0);
        answers.deleteAnswer(ans.getId());
        List<Answer> updatedList = answers.getAnswersForQuestion(30);
        assertTrue(updatedList.isEmpty());
    }

    @Test
    public void testMultipleAnswersForSameQuestion() {
        answers.addAnswer(40, "First answer for question 40", "Bob");
        answers.addAnswer(40, "Second answer for question 40", "John");
        List<Answer> answerList = answers.getAnswersForQuestion(40);
        assertEquals(2, answerList.size());
    }

    @Test
    public void testRetrieveEmptyAnswers() {
        List<Answer> answerList = answers.getAnswersForQuestion(50);
        assertTrue(answerList.isEmpty());
    }
}
